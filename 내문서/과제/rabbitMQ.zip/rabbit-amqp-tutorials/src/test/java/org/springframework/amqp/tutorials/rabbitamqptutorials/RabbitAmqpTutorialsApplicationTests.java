package org.springframework.amqp.tutorials.rabbitamqptutorials;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitAmqpTutorialsApplicationTests {

	@Test
	void contextLoads() {
	}

}
