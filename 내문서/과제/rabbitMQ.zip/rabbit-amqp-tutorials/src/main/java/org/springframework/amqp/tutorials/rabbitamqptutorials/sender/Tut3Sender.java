package org.springframework.amqp.tutorials.rabbitamqptutorials.sender;

import org.spring.framework.ampq.vo.Message;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



public class Tut3Sender {
    @Autowired
    private RabbitTemplate template;

    @Autowired
    private FanoutExchange fanout; //Tut3Config에서 설정
    int i=0;
    private ObjectMapper mapper =  new ObjectMapper();
    @Scheduled(fixedDelay = 1000, initialDelay = 500)
    public void send() throws JsonProcessingException {
    	
        Message message = new Message("asdfg",10,"ttif");
        String json = mapper.writeValueAsString(message);
        this.template.convertAndSend(fanout.getName(),"", json);
        System.out.println(" [x] Sent '" + "message" + "'");
    }
}
