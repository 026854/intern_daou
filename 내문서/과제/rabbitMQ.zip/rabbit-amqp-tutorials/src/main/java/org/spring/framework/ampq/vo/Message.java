package org.spring.framework.ampq.vo;

public class Message {
	private String path;
	private int size;
	private String type;
	
	public Message() {
		// TODO Auto-generated constructor stub
	}

	public Message(String path, int size, String type) {
		super();
		this.path = path;
		this.size = size;
		this.type = type;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	

}
