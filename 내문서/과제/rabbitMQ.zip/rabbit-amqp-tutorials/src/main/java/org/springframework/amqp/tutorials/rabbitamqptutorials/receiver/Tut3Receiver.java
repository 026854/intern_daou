package org.springframework.amqp.tutorials.rabbitamqptutorials.receiver;

import java.io.IOException;

import org.spring.framework.ampq.vo.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.util.StopWatch;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Tut3Receiver {
	ObjectMapper mapper  = new ObjectMapper();
    @RabbitListener(queues = "#{autoDeleteQueue1.name}")
    public void receive1(String in) throws InterruptedException, JsonParseException, JsonMappingException, IOException {
        receive(in, 1);
    }

    @RabbitListener(queues = "#{autoDeleteQueue2.name}")
    public void receive2(String in) throws InterruptedException, JsonParseException, JsonMappingException, IOException {
        receive(in, 2);
    }

    public void receive(String message, int receiver) throws InterruptedException, JsonParseException, JsonMappingException, IOException {
        StopWatch watch = new StopWatch();
        watch.start();
        Message in = mapper.readValue(message, Message.class);
        System.out.println("instance " + receiver + " [x] Received '" + in.getPath() + "'");
        doWork(in.getPath());
        watch.stop();
        System.out.println("instance " + receiver + " [x] Done in "
                + watch.getTotalTimeSeconds() + "s");
    }

    private void doWork(String in) throws InterruptedException {
        for (char ch : in.toCharArray()) {
            if (ch == '.') {
                Thread.sleep(1000);
            }
        }
    }
}
